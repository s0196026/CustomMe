package com.example.customme

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.customme.databinding.ItemFiltersBinding
import com.example.customme.databinding.ItemPostBinding

class PostAdapter(
    private val showFilters: Boolean = true,
    private val onPostClick: (Post) -> Unit = {},
    private val onMenuClick: (Post) -> Unit = onPostClick
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val typeFilters = 0
    private val typePost = 1

    private var posts: List<Post> = emptyList()

    private val headerCount: Int
        get() = if (showFilters) 1 else 0

    inner class FiltersViewHolder(val binding: ItemFiltersBinding) :
        RecyclerView.ViewHolder(binding.root)

    inner class PostViewHolder(val binding: ItemPostBinding) :
        RecyclerView.ViewHolder(binding.root)

    fun submitList(newPosts: List<Post>) {
        posts = newPosts
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        return if (showFilters && position == 0) typeFilters else typePost
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        return if (viewType == typeFilters) {
            FiltersViewHolder(ItemFiltersBinding.inflate(inflater, parent, false))
        } else {
            PostViewHolder(ItemPostBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is PostViewHolder) {
            val post = posts[position - headerCount]
            val cover = post.coverUrl

            with(holder.binding) {
                postTitle.text = post.title

                val stars = PostComplexity.normalize(post.complexity)
                postComplexity.text = stars
                postComplexity.isVisible = stars.isNotBlank()

                if (!cover.isNullOrBlank()) {
                    postImage.load(cover) {
                        crossfade(true)
                        placeholder(android.R.drawable.ic_menu_gallery)
                        error(android.R.drawable.ic_menu_gallery)
                    }
                } else {
                    postImage.setImageResource(android.R.drawable.ic_menu_gallery)
                }

                root.setOnClickListener { onPostClick(post) }
                btnMore.setOnClickListener { onMenuClick(post) }
                btnHeart.setOnClickListener { onPostClick(post) }
            }
        }
    }

    override fun getItemCount(): Int = posts.size + headerCount
}
