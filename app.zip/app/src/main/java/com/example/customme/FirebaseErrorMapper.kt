package com.example.customme

import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.storage.StorageException
import java.io.FileNotFoundException

object FirebaseErrorMapper {

    fun message(error: Throwable): String {
        return when (error) {
            is FirebaseFirestoreException -> when (error.code) {
                FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                    "Нет доступа к базе данных. Проверьте правила Firestore"
                FirebaseFirestoreException.Code.UNAVAILABLE ->
                    "База данных недоступна. Проверьте интернет"
                FirebaseFirestoreException.Code.UNAUTHENTICATED ->
                    "Сессия истекла. Войдите заново"
                else -> error.localizedMessage ?: "Ошибка базы данных"
            }

            is StorageException -> when (error.errorCode) {
                StorageException.ERROR_NOT_AUTHORIZED ->
                    "Нет доступа к хранилищу. Проверьте storage.rules и войдите заново"
                StorageException.ERROR_OBJECT_NOT_FOUND ->
                    "Хранилище Firebase не настроено или недоступно: бакет не найден. " +
                        "Включите Storage в Firebase Console и примените storage.rules"
                StorageException.ERROR_QUOTA_EXCEEDED ->
                    "Закончилось место в хранилище"
                else -> error.localizedMessage ?: "Ошибка загрузки изображения"
            }

            is FileNotFoundException ->
                "Не удалось открыть выбранное изображение. Выберите его заново"

            is SecurityException ->
                "Нет доступа к выбранному изображению. Выберите его заново"

            else -> error.localizedMessage ?: "Не удалось выполнить действие"
        }
    }
}
